package debtsproject;
import View.Viewer;

public class DebtsProject {
    public static void main(String[] args) {
        Viewer view = new Viewer();
        view.setVisible(true);
    }
    
}
