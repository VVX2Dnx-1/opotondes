package Controller;
import View.Viewer;
import  java.util.List;
import  Model.Debt.*;
import  Model.People.*;
import Model.ModelTabel;


public class Controller {
    private Viewer view;
    private DAOPeople daoPip;
    private DAODebt daoDeb;
    
    public Controller(Viewer view){
        this.view = view;
        this.daoPip = new DAOPeople();
        this.daoDeb = new DAODebt();
    }
    
    
    
    
    private void loadPeopleData(){
        List<ModelPeople> pipelList = daoPip.getAll();
        view.getPemberiComboBox().removeAllItems();
        view.getPenerimaComboBox().removeAllItems();
        
        for(ModelPeople people : pipelList){
           
        }
        
    }
}
