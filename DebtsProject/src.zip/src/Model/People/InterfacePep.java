
package Model.People;
import java.util.List;

public interface InterfacePep {
    public void insert(ModelPeople people);
    public List<ModelPeople> getAll();
}
